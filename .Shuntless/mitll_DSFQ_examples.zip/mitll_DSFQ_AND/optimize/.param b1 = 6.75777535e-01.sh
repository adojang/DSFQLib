	.param b1   =  6.75777535e-01
	.param b3   =  3.67307351e-01
	.param b5   =  1.59808146e+00
	.param i1   =  4.03107347e-05
	.param l1   =  5.24052921e-12
	.param r3   =  5.47957506e-01
	.param r1   =  1.42746703e+00
