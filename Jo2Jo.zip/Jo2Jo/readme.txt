Copy the .param from your netlist into netlist.txt
Copy the mess that josim-tools outputs into mess.txt

run:

Jo2Jo -i netlist.txt -m mess.txt